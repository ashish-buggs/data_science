import matplotlib.pyplot as plt 
from PIL import Image 
import numpy as np 
sPicNameIn='D:/MSC IT/SEM I/502 Data Science PR 2Cr/M.Sc IT Practical DS/Practical 7/ImagePr7.jpg' 
imageIn = Image.open(sPicNameIn) 
fig1=plt.figure(figsize=(10, 10)) 
fig1.suptitle('Office', fontsize=20) 
imgplot = plt.imshow(imageIn) 
plt.show() 
 
imagewidth, imageheight = imageIn.size 
imageMatrix=np.asarray(imageIn) 
pixelscnt = (imagewidth * imageheight) 
print('Pixels:', pixelscnt) 
print('Size:', imagewidth, ' x', imageheight,) 
print(imageMatrix)
