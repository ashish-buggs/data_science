import pandas as pd
import sqlite3

# 1. Connect to the database
conn = sqlite3.connect("project.db")  # Use your database file name
cursor = conn.cursor()
print("Connected to the database!")

# 2. Create a table (if not exists)
create_table_query = """
CREATE TABLE IF NOT EXISTS IP_DATA_ALL (
    RowIDCSV INTEGER PRIMARY KEY,
    IP_Address TEXT,
    Country TEXT,
    Region TEXT,
    City TEXT,
    ISP TEXT
)
"""
cursor.execute(create_table_query)
conn.commit()
print("Table created (if it didn't exist).")

# 3. Load CSV into pandas
df = pd.read_csv("IP_DATA_ALL.csv")  # Make sure your CSV is in the same folder
print("CSV loaded with shape:", df.shape)

# 4. Store data into SQLite
df.to_sql("IP_DATA_ALL", conn, if_exists="replace", index=False)
print("Data stored in the database successfully!")

# 5. Query the data
query = "SELECT * FROM IP_DATA_ALL LIMIT 5;"  # Example: get first 5 rows
result = pd.read_sql(query, conn)
print(result)

# 6. Close the connection
conn.close()
print("Database connection closed.")
