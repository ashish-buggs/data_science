import sqlite3

# Connect to a database file. If the file doesn't exist, it is created.
conn = sqlite3.connect('project.db')

# You can also create a temporary in-memory database by passing ':memory:'
# conn = sqlite3.connect(':memory:')

print("Database created and connection established.")

# A cursor object is used to execute SQL commands
cursor = conn.cursor()

# Execute a CREATE TABLE statement
cursor.execute('''
CREATE TABLE IF NOT EXISTS projects (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    start_date TEXT
);
''')

# Commit the changes (essential for INSERT/UPDATE/DELETE operations)
conn.commit()

# Close the connection
conn.close()
